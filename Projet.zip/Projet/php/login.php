<?php
 session_start();

 require 'config.php';

 $email = mysqli_real_escape_string($connection,$_POST['email']);
 $pswd = mysqli_real_escape_string($connection,$_POST['pswd']);

if (!empty($email) && !empty($pswd)) {
    $sql = mysqli_query($connection,"SELECT * FROM users WHERE email = '$email'");
   if (mysqli_num_rows($sql) > 0) {
    $row = mysqli_fetch_assoc($sql);
    $ps = $row['password'];
    if ($pswd === $ps) {
        $_SESSION['user_id'] = $row['user_id'];
        header("location: index.php");
    }else {
        echo "mot de passe incorrect";
        header("location: ../login_signup.html");

    }
   }else {
    echo "Cet email n'existe pas";
    header("location: ../login_signup.html");

   }

    
}