<?php

session_start();

require 'config.php';
date_default_timezone_set('Etc/GMT-1');
$moment = date("d/m/Y H:i");
$user_id = rand(1,100000);

$name = mysqli_real_escape_string($connection,$_POST['name']);
$prenom = mysqli_real_escape_string($connection,$_POST['prenom']);
$email = mysqli_real_escape_string($connection,$_POST['email']);
$pswd = mysqli_real_escape_string($connection,$_POST['pswd']);
// $photo = mysqli_real_escape_string($connection,$_POST['photo']);


$sentelement = "INSERT INTO users(fname, lname, email, password, login_date, user_id) VALUES (
    '$name', '$prenom', '$email', '$pswd', '$moment','$user_id')";

$sqli = mysqli_query($connection, $sentelement);

if (!$sqli) {
    echo"problème";
}else{
    echo"ok";
    $_SESSION['user_id'] = $user_id;
    header("location: index.php");
}


?>