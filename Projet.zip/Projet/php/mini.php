<?php
        date_default_timezone_set('Etc/GMT-1');

echo date("d M Y H:i")."\n";

echo date('d/m/Y H:i')."\n";

$rp = rand(1,100000);
$re = md5($rp);

echo $rp."\n";
echo $re;