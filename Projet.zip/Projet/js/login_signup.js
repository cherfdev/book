const loginText = document.querySelector(".title-text .login");
const loginForm = document.querySelector("form.login");
const loginBtn = document.querySelector("label.login");
const signupBtn = document.querySelector("label.signup");
const signupLink = document.querySelector("form .signup-link a"),
signup_tag = document.querySelector("#signup_tag"),
disable_temp = document.querySelector(".disable_temp"),
psw1 = document.querySelector("#pswd1"),
psw2 = document.querySelector("#pswd2");

disable_temp.style.display='none';

signupBtn.onclick = (()=>{
 loginForm.style.marginLeft = "-50%";
 loginText.style.marginLeft = "-50%";
});
loginBtn.onclick = (()=>{
 loginForm.style.marginLeft = "0%";
 loginText.style.marginLeft = "0%";
});
signupLink.onclick = (()=>{
 signupBtn.click();
 return false;
});

signup_tag.addEventListener("click",()=>{
    if (psw1.value != psw2.value) {
        disable_temp.style.display='block';
        document.querySelector(".error-msg").textContent="Saisissez le mème mot de passe";
    }else{
        disable_temp.style.display='none';
        document.querySelector(".error-msg").textContent="";
    }
})

psw1.addEventListener("keydown",()=>{
    if (psw1.value.length < 8) {
        disable_temp.style.display='block';
        disable_temp.style.color='red';
        disable_temp.style.background='white';
        document.querySelector(".error-msg").textContent="Au moins 8 caractères";
    }else{
        document.querySelector(".error-msg").textContent="Mot de passe fort";
        setTimeout(() => {
            disable_temp.style.transition ='all .3s ease-in-out';
            disable_temp.style.display='none';

        }, 2000);
    }
})